import { config } from "dotenv";
config();
 

const {
    DB_USER,
    DB_PASSWORD,
    DB_ADDRESS,
    DB_CLUSTER,
    DB_NAME,
    DATA_DIRECTORY,
    ADVISORY_JSON_URL,
    ADVISORY_JSON_FILENAME,
    ISO_COUNTRIES_JSON_FILENAME,
    USERS_JSON_FILENAME,
    PORT
} = process.env;

export default {
    DB_USER,
    DB_PASSWORD,
    DB_ADDRESS,
    DB_CLUSTER,
    DB_NAME,
    DATA_DIRECTORY,
    ADVISORY_JSON_URL,
    ADVISORY_JSON_FILENAME,
    ISO_COUNTRIES_JSON_FILENAME,
    USERS_JSON_FILENAME,
    PORT
};